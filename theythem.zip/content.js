// Global set for fast lookup of names.
let namesSet = new Set();

// Load names from the JSON file and populate namesSet (converted to uppercase for consistency)
function loadNames() {
  return fetch(chrome.runtime.getURL('clean_official_names.json'))
    .then(response => response.json())
    .then(names => {
      names.forEach(name => {
        let cleaned = name.trim();
        // Optionally remove a leading "A " if present.
        if (cleaned.startsWith("A ")) {
          cleaned = cleaned.substring(2).trim();
        }
        if (cleaned) {
          namesSet.add(cleaned.toUpperCase());
        }
      });
    })
    .catch(err => console.error('Error loading names:', err));
}

// Process a single Twitter element.
// This function will look for any occurrence of two consecutive capitalized words
// and if the candidate (converted to uppercase) exists in namesSet, it replaces it with the formatted string.
function processTwitterElement(element) {
  // Skip if already processed.
  if (element.dataset.processed === "true") return;
  
  let fullText = element.textContent;
  // Regular expression to match two consecutive words that start with a capital letter.
  // This assumes names are formatted as "First Last" (without extra punctuation).
  const nameRegex = /\b([A-Z][a-z]+)\s+([A-Z][a-z]+)\b/g;
  
  // Replace each candidate in the text.
  let newText = fullText.replace(nameRegex, (match, p1, p2) => {
    // Check if the candidate (in uppercase) is in our namesSet.
    if (namesSet.has(match.toUpperCase())) {
      return "$(" + match + ")$";
    }
    return match;
  });
  
  // Update the element's text if any changes were made.
  if (newText !== fullText) {
    element.textContent = newText;
  }
  // Mark this element as processed.
  element.dataset.processed = "true";
}

// Process all Twitter elements with the given CSS classes.
function processTwitterNames() {
  // Query for Twitter name or tweet text elements.
  const elements = document.querySelectorAll('span.css-1jxf684.r-bcqeeo.r-1ttztb7.r-qvutc0.r-poiln3');
  elements.forEach(element => {
    processTwitterElement(element);
  });
}

// Set up a MutationObserver to process newly added nodes.
function observeMutations() {
  const observer = new MutationObserver(mutations => {
    mutations.forEach(mutation => {
      if (mutation.addedNodes.length > 0) {
        // Slight delay to allow new nodes to settle.
        setTimeout(processTwitterNames, 50);
      }
    });
  });
  observer.observe(document.body, { childList: true, subtree: true });
}

// Load the names, process initial Twitter elements, and observe dynamic changes.
loadNames().then(() => {
  processTwitterNames();
  observeMutations();
});

